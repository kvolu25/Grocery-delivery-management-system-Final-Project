Documentation
- brochure.pdf (marketing flyer)
- system_requirements.pdf (complete SRS)
- presentation_slides.pptx (final demo deck)

Author: Voluntas Kini
Project: Grocery Delivery Management System
Demo: https://drive.google.com/file/d/1hI0uHCqcEKYtwMSVQh_y6Sazb4hax8Bw/view?usp=drive_link
