import json

def test_checkout_creates_order_and_returns_id(client):
    payload = {
        "address": {"street": "123 Main", "city": "Whitestown", "state": "IN", "zip": "46075"},
        "payment": {"card_last4": "4242"},
    }
    r = client.post('/api/checkout', json=payload)
    assert r.status_code in (200, 201)
    body = json.loads(r.data.decode('utf-8'))
    assert 'order_id' in body
