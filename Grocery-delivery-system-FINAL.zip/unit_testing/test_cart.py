import json

def test_add_to_cart_then_get_cart(client):
    payload = {"item_id": 1, "qty": 2}
    r_post = client.post('/api/cart', json=payload)
    assert r_post.status_code in (200, 201)

    r_get = client.get('/api/cart')
    assert r_get.status_code == 200
    data = json.loads(r_get.data.decode('utf-8'))
    assert 'items' in data and data['total'] > 0
