import json

def test_catalog_list_returns_items(client):
    resp = client.get('/api/catalog')
    assert resp.status_code == 200
    data = json.loads(resp.data.decode('utf-8'))
    assert isinstance(data, list) and len(data) > 0
