def test_home_returns_200_and_welcome_text(client):
    resp = client.get('/')
    assert resp.status_code == 200
    assert b'Grocery Delivery Management System' in resp.data
