Unit Testing — Senior Package

Run:
- pip install -r unit_testing/requirements-unit.txt
- pytest -q --cov=code --cov-report=term-missing
