import os, requests, pytest
BASE_URL = os.getenv('GDMS_BASE_URL', 'http://127.0.0.1:5000')

@pytest.mark.integration
def test_browse_catalog_and_add_to_cart(app_server):
    r = requests.get(f"{BASE_URL}/api/catalog", timeout=5)
    assert r.status_code == 200
    items = r.json()
    assert isinstance(items, list) and len(items) > 0
    item_id = items[0]['id']
    r = requests.post(f"{BASE_URL}/api/cart", json={'item_id': item_id, 'qty': 2}, timeout=5)
    assert r.status_code in (200, 201)
    r = requests.get(f"{BASE_URL}/api/cart", timeout=5)
    cart = r.json()
    assert cart['total'] > 0

@pytest.mark.integration
def test_checkout_and_order_tracking(app_server):
    payload = {
        'address': {'street': '123 Main', 'city': 'Whitestown', 'state': 'IN', 'zip': '46075'},
        'payment': {'card_last4': '4242'},
    }
    r = requests.post(f"{BASE_URL}/api/checkout", json=payload, timeout=10)
    assert r.status_code in (200, 201)
    order_id = r.json()['order_id']
    r = requests.get(f"{BASE_URL}/api/orders/{order_id}/status", timeout=5)
    assert r.status_code == 200
    assert r.json()['status'] in ('placed','packed','out_for_delivery','delivered')
