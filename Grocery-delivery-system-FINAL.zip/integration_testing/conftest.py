import os, time, subprocess, signal, requests, pytest
BASE_URL = os.getenv('GDMS_BASE_URL', 'http://127.0.0.1:5000')
HEALTH_PATH = '/'

@pytest.fixture(scope='session')
def app_server():
    proc = subprocess.Popen(['python', 'code/wsgi.py'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    timeout_s = 30
    start = time.time()
    last_err = None
    while time.time() - start < timeout_s:
        try:
            r = requests.get(f"{BASE_URL}{HEALTH_PATH}", timeout=2)
            if r.status_code < 500:
                break
        except Exception as e:
            last_err = e
        time.sleep(0.5)
    else:
        proc.kill()
        raise RuntimeError(f"App did not become healthy at {BASE_URL}{HEALTH_PATH}. Last error: {last_err}")
    yield proc
    os.kill(proc.pid, signal.SIGTERM)
