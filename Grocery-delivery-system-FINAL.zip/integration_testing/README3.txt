Integration Testing — Senior Package

Run:
- pip install -r integration_testing/requirements-integration.txt
- pytest -m integration --timeout=30 -q
