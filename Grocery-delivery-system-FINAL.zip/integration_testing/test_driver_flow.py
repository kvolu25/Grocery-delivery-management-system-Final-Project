import os, requests, pytest
BASE_URL = os.getenv('GDMS_BASE_URL', 'http://127.0.0.1:5000')

@pytest.mark.integration
def test_driver_updates_status(app_server):
    payload = {
        'address': {'street': '123 Main', 'city': 'Whitestown', 'state': 'IN', 'zip': '46075'},
        'payment': {'card_last4': '4242'},
    }
    r = requests.post(f"{BASE_URL}/api/checkout", json=payload, timeout=10)
    order_id = r.json()['order_id']
    r = requests.post(f"{BASE_URL}/api/driver/order/{order_id}/status", json={'status': 'on_the_way'}, timeout=5)
    assert r.status_code in (200, 204)
    r = requests.post(f"{BASE_URL}/api/driver/order/{order_id}/status", json={'status': 'delivered'}, timeout=5)
    assert r.status_code in (200, 204)
