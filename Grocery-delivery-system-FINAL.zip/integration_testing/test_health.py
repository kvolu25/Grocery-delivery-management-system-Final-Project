import os, requests, pytest
BASE_URL = os.getenv('GDMS_BASE_URL', 'http://127.0.0.1:5000')

@pytest.mark.integration
def test_home_endpoint(app_server):
    r = requests.get(f"{BASE_URL}/", timeout=5)
    assert r.status_code == 200
    assert 'Grocery Delivery Management System' in r.text
