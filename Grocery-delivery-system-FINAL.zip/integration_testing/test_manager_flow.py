import os, requests, pytest
BASE_URL = os.getenv('GDMS_BASE_URL', 'http://127.0.0.1:5000')

@pytest.mark.integration
def test_inventory_management_and_assignment(app_server):
    new_item = {'name': 'Bananas', 'price': 1.29, 'stock': 100}
    r = requests.post(f"{BASE_URL}/api/manager/inventory", json=new_item, timeout=5)
    assert r.status_code in (200, 201)
    item_id = r.json()['id']
    r = requests.patch(f"{BASE_URL}/api/manager/inventory/{item_id}", json={'stock': 95}, timeout=5)
    assert r.status_code == 200
    assert r.json()['stock'] == 95
    r = requests.post(f"{BASE_URL}/api/manager/assign", json={'order_id': 1, 'driver_id': 7}, timeout=5)
    assert r.status_code in (200, 204)
