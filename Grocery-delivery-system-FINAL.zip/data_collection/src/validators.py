import logging

def validate_catalog_records(records):
    valid = []
    invalid = 0
    for r in records:
        if not isinstance(r, dict):
            invalid += 1
            continue
        name = r.get('name')
        price = r.get('price')
        if not name:
            invalid += 1
            continue
        try:
            price_val = float(price)
        except (TypeError, ValueError):
            invalid += 1
            continue
        valid.append({'name': name, 'price': price_val})
    logging.getLogger('data_collection').info('Validation complete: %s valid, %s invalid', len(valid), invalid)
    return valid, invalid
