import os, yaml, requests, pandas as pd
from utils import setup_logging, ensure_dir, timestamped_filename
from validators import validate_catalog_records

def main():
    log = setup_logging()
    cfg = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), '..', 'config.yaml')))
    api_cfg = cfg.get('api_collection', {})
    if not api_cfg.get('enabled', False):
        log.info('API collection disabled in config.')
        return
    url = api_cfg['url']
    timeout = api_cfg.get('timeout_seconds', 10)
    headers = api_cfg.get('headers', {})
    log.info('Requesting API: %s', url)
    resp = requests.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    data = resp.json()
    valid, invalid = validate_catalog_records(data)
    out_dir = ensure_dir(cfg['output_dir'])
    out_path = os.path.join(out_dir, timestamped_filename('catalog_api'))
    pd.DataFrame(valid).to_csv(out_path, index=False)
    log.info('Saved %s records to %s (invalid=%s)', len(valid), out_path, invalid)

if __name__ == '__main__':
    main()
