import os, yaml, requests, pandas as pd
from bs4 import BeautifulSoup
from utils import setup_logging, ensure_dir, timestamped_filename
from validators import validate_catalog_records

def parse_items(soup, selector):
    records = []
    for item in soup.select(selector):
        name_el = item.select_one('.name')
        price_el = item.select_one('.price')
        name = name_el.get_text(strip=True) if name_el else None
        price = (price_el.get_text(strip=True).replace('$','') if price_el else None)
        records.append({'name': name, 'price': price})
    return records

def main():
    log = setup_logging()
    cfg = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), '..', 'config.yaml')))
    html_cfg = cfg.get('html_collection', {})
    if not html_cfg.get('enabled', False):
        log.info('HTML collection disabled in config.')
        return
    url = html_cfg['url']
    timeout = html_cfg.get('timeout_seconds', 10)
    selector = html_cfg['css_selector']
    log.info('Fetching HTML page: %s', url)
    resp = requests.get(url, timeout=timeout)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, 'html.parser')
    raw_records = parse_items(soup, selector)
    valid, invalid = validate_catalog_records(raw_records)
    out_dir = ensure_dir(cfg['output_dir'])
    out_path = os.path.join(out_dir, timestamped_filename('catalog_html'))
    pd.DataFrame(valid).to_csv(out_path, index=False)
    log.info('Saved %s records to %s (invalid=%s)', len(valid), out_path, invalid)

if __name__ == '__main__':
    main()
