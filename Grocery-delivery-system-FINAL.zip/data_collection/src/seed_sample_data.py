import os, yaml, pandas as pd
from utils import setup_logging, ensure_dir, timestamped_filename

def main():
    log = setup_logging()
    cfg = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), '..', 'config.yaml')))
    sample_cfg = cfg.get('sample_data', {})
    if not sample_cfg.get('enabled', True):
        log.info('Sample seeding disabled in config.')
        return
    items = sample_cfg.get('items', [])
    out_dir = ensure_dir(cfg['output_dir'])
    out_path = os.path.join(out_dir, timestamped_filename('catalog_seed'))
    pd.DataFrame(items).to_csv(out_path, index=False)
    log.info('Seeded %s items to %s', len(items), out_path)

if __name__ == '__main__':
    main()
