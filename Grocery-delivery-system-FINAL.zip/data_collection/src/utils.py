import os, logging
from datetime import datetime

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    return logging.getLogger('data_collection')

def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path

def timestamped_filename(prefix: str, ext: str = 'csv') -> str:
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{prefix}_{ts}.{ext}"
