Data Collection — Senior Package
Run:
- pip install -r data_collection/requirements-data.txt
- python data_collection/src/seed_sample_data.py
- python data_collection/src/collect_api.py
- python data_collection/src/collect_html.py
