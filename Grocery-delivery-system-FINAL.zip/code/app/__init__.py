from flask import Flask
from .blueprints.public import bp as public_bp
from .blueprints.api import bp as api_bp
from .config import Config


def create_app(config_class: type = Config) -> Flask:
    app = Flask(__name__, template_folder='app/templates')
    app.config.from_object(config_class)

    # Register blueprints
    app.register_blueprint(public_bp)
    app.register_blueprint(api_bp, url_prefix='/api')

    return app
