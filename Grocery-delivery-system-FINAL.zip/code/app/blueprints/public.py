from flask import Blueprint, render_template

bp = Blueprint('public', __name__)

WELCOME = 'Welcome to Grocery Delivery Management System'

@bp.route('/')
def home():
    try:
        return render_template('index.html')
    except Exception:
        return f"<h1>{WELCOME}</h1>", 200
