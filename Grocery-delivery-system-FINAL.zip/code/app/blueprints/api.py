from flask import Blueprint, jsonify, request

bp = Blueprint('api', __name__)

catalog = [
    {"id": 1, "name": "Apples", "price": 1.99},
    {"id": 2, "name": "Bananas", "price": 0.99},
    {"id": 3, "name": "Milk", "price": 2.49},
]
cart = []
orders = {}
next_order_id = 1

@bp.get('/catalog')
def get_catalog():
    return jsonify(catalog), 200

@bp.route('/cart', methods=['GET','POST'])
def cart_endpoint():
    global cart
    if request.method == 'POST':
        data = request.get_json(force=True)
        cart.append({"item_id": data.get('item_id'), "qty": data.get('qty', 1)})
        return jsonify({"message":"added"}), 201
    total = sum([next((i['price'] for i in catalog if i['id']==c['item_id']),0)*c['qty'] for c in cart])
    return jsonify({"items": cart, "total": total}), 200

@bp.post('/checkout')
def checkout():
    global next_order_id, orders, cart
    payload = request.get_json(force=True)
    order_id = next_order_id
    next_order_id += 1
    orders[order_id] = {
        "status": "placed",
        "address": payload.get("address", {}),
        "payment": payload.get("payment", {}),
    }
    cart = []
    return jsonify({"order_id": order_id}), 201

@bp.get('/orders/<int:order_id>/status')
def order_status(order_id: int):
    order = orders.get(order_id)
    if not order:
        return jsonify({"error":"not found"}), 404
    return jsonify({"status": order["status"]}), 200

@bp.post('/manager/inventory')
def add_inventory():
    item = request.get_json(force=True)
    new_id = max([i['id'] for i in catalog]) + 1 if catalog else 1
    item['id'] = new_id
    catalog.append(item)
    return jsonify({"id": new_id, **item}), 201

@bp.patch('/manager/inventory/<int:item_id>')
def update_inventory(item_id: int):
    data = request.get_json(force=True)
    for i in catalog:
        if i['id'] == item_id:
            i.update(data)
            return jsonify(i), 200
    return jsonify({"error":"not found"}), 404

@bp.post('/manager/assign')
def assign_order():
    return ('', 204)

@bp.post('/driver/order/<int:order_id>/status')
def driver_update(order_id: int):
    data = request.get_json(force=True)
    if order_id in orders:
        orders[order_id]['status'] = data.get('status','placed')
        return ('', 204)
    return jsonify({"error":"not found"}), 404
